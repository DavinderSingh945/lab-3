
type Coach = {
    Name: string
    FormerPlayer: bool
}

type Stats = {
    Wins: int
    Losses: int
}

type Team = {
    Name: string
    Coach: Coach
    Stats: Stats
}

let teams = [
    { Name = "Los Angeles Lakers"; Coach = { Name = "Darvin Ham"; FormerPlayer = true }; Stats = { Wins = 45; Losses = 37 } }
    { Name = "Golden State Warriors"; Coach = { Name = "Steve Kerr"; FormerPlayer = true }; Stats = { Wins = 44; Losses = 38 } }
    { Name = "Brooklyn Nets"; Coach = { Name = "Jacque Vaughn"; FormerPlayer = true }; Stats = { Wins = 40; Losses = 42 } }
    { Name = "Miami Heat"; Coach = { Name = "Erik Spoelstra"; FormerPlayer = false }; Stats = { Wins = 47; Losses = 35 } }
    { Name = "Boston Celtics"; Coach = { Name = "Joe Mazzulla"; FormerPlayer = false }; Stats = { Wins = 54; Losses = 28 } }
]

let successfulTeams = 
    teams |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)

let successPercentage team =
    let totalGames = float (team.Stats.Wins + team.Stats.Losses)
    let successRate = (float team.Stats.Wins / totalGames) * 100.0
    successRate

let teamSuccessPercentages =
    teams |> List.map (fun team -> (team.Name, successPercentage team))
    
successfulTeams |> List.iter (fun team -> printfn "%s - Wins: %d, Losses: %d" team.Name team.Stats.Wins team.Stats.Losses)
teamSuccessPercentages |> List.iter (fun (name, percentage) -> printfn "%s - Success Percentage: %.2f%%" name percentage)



type Cuisine =
    | Korean
    | Turkish

type MovieType =
    | Regular
    | IMAX
    | DBOX
    | RegularWithSnacks
    | IMAXWithSnacks
    | DBOXWithSnacks

type Activity =
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float 


let calculateBudget activity =
    match activity with
    | BoardGame -> 0.0 
    | Chill -> 0.0 
    | Movie movieType ->
        match movieType with
        | Regular -> 12.0 
        | IMAX -> 17.0 
        | DBOX -> 20.0 
        | RegularWithSnacks | IMAXWithSnacks | DBOXWithSnacks -> 
            match movieType with
            | RegularWithSnacks | IMAXWithSnacks | DBOXWithSnacks -> 25.0 
            | _ -> 12.0 
    | Restaurant cuisine ->
        match cuisine with
        | Korean -> 70.0 
        | Turkish -> 65.0 
    | LongDrive (km, fuelPerKm) -> 
        
        float km * fuelPerKm 


let activity1 = Movie Regular
let activity2 = Restaurant Korean
let activity3 = LongDrive (50, 1.2) 


printfn "Budget for activity1 (Movie): %.2f CAD" (calculateBudget activity1)
printfn "Budget for activity2 (Restaurant): %.2f CAD" (calculateBudget activity2)
printfn "Budget for activity3 (LongDrive): %.2f CAD" (calculateBudget activity3)


let activity4 = Movie IMAXWithSnacks
let activity5 = Restaurant Turkish

printfn "Budget for activity4 (IMAXWithSnacks): %.2f CAD" (calculateBudget activity4)
printfn "Budget for activity5 (Restaurant - Turkish): %.2f CAD" (calculateBudget activity5)