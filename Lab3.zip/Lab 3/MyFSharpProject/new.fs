let x = fun n -> n*n

let square = [2;3;4;5]> List.map x

printfn "%aA" square